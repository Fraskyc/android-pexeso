package com.example.pexeso;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.widget.GridLayout;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class GameActivity extends AppCompatActivity {

    private GridLayout grid;
    private TextView tvMoves;

    private List<Integer> cardValues;
    private ImageButton firstCard = null;
    private ImageButton secondCard = null;
    private int firstIndex = -1;
    private int secondIndex = -1;
    private boolean isBusy = false;
    private int moves = 0;
    private int matchedPairs = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        grid = new GridLayout(this);
        grid.setColumnCount(8);
        grid.setRowCount(4);
        grid.setUseDefaultMargins(true);

        setContentView(grid);

        tvMoves = new TextView(this);
        tvMoves.setTextSize(20);
        tvMoves.setText("Tahů: 0");
        addContentView(tvMoves, new GridLayout.LayoutParams());

        prepareCards();
        createBoard();
    }

    private void prepareCards() {
        cardValues = new ArrayList<>();
        for (int i = 0; i < 16; i++) {
            cardValues.add(i);
            cardValues.add(i);
        }
        Collections.shuffle(cardValues);
    }

    private void createBoard() {
        for (int i = 0; i < 32; i++) {
            ImageButton card = new ImageButton(this);
            card.setBackgroundResource(R.drawable.card_back);

            GridLayout.LayoutParams params = new GridLayout.LayoutParams();
            params.width = 0;
            params.height = 0;
            params.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
            params.rowSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
            card.setLayoutParams(params);

            final int index = i;
            card.setOnClickListener(v -> onCardClicked(card, index));

            grid.addView(card);
        }
    }

    private void onCardClicked(ImageButton card, int index) {
        if (isBusy) return;
        if (card == firstCard || card == secondCard) return;

        showCardFront(card, cardValues.get(index));

        if (firstCard == null) {
            firstCard = card;
            firstIndex = index;
        } else if (secondCard == null) {
            secondCard = card;
            secondIndex = index;
            moves++;
            tvMoves.setText("Tahů: " + moves);
            checkMatch();
        }
    }

    private void checkMatch() {
        int v1 = cardValues.get(firstIndex);
        int v2 = cardValues.get(secondIndex);

        if (v1 == v2) {
            firstCard.setEnabled(false);
            secondCard.setEnabled(false);
            firstCard.setAlpha(0f);
            secondCard.setAlpha(0f);

            matchedPairs++;

            resetSelection();

            if (matchedPairs == 16) {
                saveHighScore();
                finish();
            }

        } else {
            isBusy = true;
            new Handler().postDelayed(() -> {
                hideCard(firstCard);
                hideCard(secondCard);
                resetSelection();
                isBusy = false;
            }, 800);
        }
    }

    private void resetSelection() {
        firstCard = null;
        secondCard = null;
        firstIndex = -1;
        secondIndex = -1;
    }

    private void showCardFront(ImageButton card, int value) {
        int resId = getResources().getIdentifier("img" + (value + 1), "drawable", getPackageName());
        card.setBackgroundResource(resId);
    }


    private void hideCard(ImageButton card) {
        card.setBackgroundResource(R.drawable.card_back);
    }

    private void saveHighScore() {
        SharedPreferences prefs = getSharedPreferences("pexeso_prefs", MODE_PRIVATE);
        int best = prefs.getInt("best_moves", Integer.MAX_VALUE);

        if (moves < best) {
            prefs.edit().putInt("best_moves", moves).apply();
        }
    }
}
