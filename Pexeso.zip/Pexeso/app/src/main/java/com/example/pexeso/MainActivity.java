package com.example.pexeso;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView tvBest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvBest = findViewById(R.id.tvBestScore);
        Button btnNewGame = findViewById(R.id.btnNewGame);

        loadHighScore();

        btnNewGame.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, GameActivity.class));
        });
    }

    private void loadHighScore() {
        SharedPreferences prefs = getSharedPreferences("pexeso_prefs", MODE_PRIVATE);
        int best = prefs.getInt("best_moves", -1);

        if (best == -1) {
            tvBest.setText("Nejlepší skóre: -");
        } else {
            tvBest.setText("Nejlepší skóre: " + best);
        }
    }
}
